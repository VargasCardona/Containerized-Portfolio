/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for Linux (x86_64)
--
-- Host: database    Database: forms
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms` (
  `id_form` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(100) NOT NULL,
  PRIMARY KEY (`id_form`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
INSERT INTO `forms` VALUES
(1,'John Doe','john.doe@example.com','Hello, I would like to know more about your services.'),
(2,'Jane Smith','jane.smith@example.com','Great portfolio! I am interested in collaborating.'),
(3,'Michael Johnson','michael.johnson@example.com','Can you provide more details about your projects?'),
(4,'Emily Davis','emily.davis@example.com','I love your work! Let’s connect.'),
(5,'David Wilson','david.wilson@example.com','What technologies do you specialize in?'),
(6,'Sophia Brown','sophia.brown@example.com','I have a question about your pricing.'),
(7,'James Jones','james.jones@example.com','Your designs are amazing! How can I hire you?'),
(8,'Olivia Garcia','olivia.garcia@example.com','I would like to discuss a project with you.'),
(9,'William Martinez','william.martinez@example.com','Can you help me with a website?'),
(10,'Isabella Hernandez','isabella.hernandez@example.com','I appreciate your talent! Let’s talk.'),
(11,'Benjamin Lee','benjamin.lee@example.com','What is your availability for new projects?'),
(12,'Charlotte Lopez','charlotte.lopez@example.com','I am impressed by your skills. How can we collaborate?'),
(13,'Lucas Walker','lucas.walker@example.com','Could you send me your portfolio?'),
(14,'Mia Hall','mia.hall@example.com','I have a project that I think you would be perfect for.'),
(15,'Henry Young','henry.young@example.com','I love your aesthetic! Can we chat?'),
(16,'Amelia King','amelia.king@example.com','I would like to know your rates.'),
(17,'Alexander Wright','alexander.wright@example.com','Can you provide references?'),
(18,'Ella Scott','ella.scott@example.com','What is your design process like?'),
(19,'Noah Green','noah.green@example.com','I am looking for a web developer. Can you help?'),
(20,'Ava Adams','ava.adams@example.com','I have an idea for a project. Can we discuss?'),
(21,'Jacob Baker','jacob.baker@example.com','I would love to see more of your work!'),
(22,'Scarlett Gonzalez','scarlett.gonzalez@example.com','How do you handle client feedback?'),
(23,'Daniel Nelson','daniel.nelson@example.com','What is your preferred method of communication?'),
(24,'Grace Carter','grace.carter@example.com','I am very interested in your services.'),
(25,'Ethan Mitchell','ethan.mitchell@example.com','Can you share your previous work samples?'),
(26,'Zoe Perez','zoe.perez@example.com','I need help with branding. Can you assist?'),
(27,'Michael Rivera','michael.rivera@example.com','Your portfolio is very inspiring!'),
(28,'Chloe Ramirez','chloe.ramirez@example.com','I have a few questions regarding your process.'),
(29,'Elijah Cooper','elijah.cooper@example.com','I would like to book a consultation.'),
(30,'Sofia Reed','sofia.reed@example.com','Do you work with startups?'),
(31,'James Evans','james.evans@example.com','What types of projects do you typically take on?'),
(32,'Aria Murphy','aria.murphy@example.com','Let’s connect! I have a project in mind.'),
(33,'Logan Rivera','logan.rivera@example.com','What are your thoughts on design trends?'),
(34,'Victoria Cook','victoria.cook@example.com','I would like to collaborate on a video project.');
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-04 16:19:25
